#pragma once

int FasmSym2CoffObj (char* szSymFile, char* szCoffFile);
int FasmSym2CoffExe (char* szSymFile, char* szExeFile);
