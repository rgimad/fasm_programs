#ifndef _TCHAREX_H
#define _TCHAREX_H

#ifndef _Null_terminated_
#define _Null_terminated_
#endif  //_Null_terminated_

typedef _Null_terminated_ const char *PCSZ;

#endif
